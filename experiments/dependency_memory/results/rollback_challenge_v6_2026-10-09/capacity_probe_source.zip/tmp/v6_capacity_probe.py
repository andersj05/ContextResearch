"""Offline reachable-state probe; scripted fixtures, zero model generations."""
from copy import deepcopy
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from experiments.dependency_memory.rollback_challenge_v6 import engine
from experiments.dependency_memory.rollback_challenge_v6.common import ROOT, WRITER_BYTES, wire, read
from experiments.dependency_memory.rollback_challenge_v6.contexts import render, parse_writer
from experiments.dependency_memory.rollback_challenge_v6.prepare import check_bundle
from experiments.dependency_memory.rollback_challenge_v6.tasks import public_check, candidate


def sequences(stages, actions, prefix=""):
    if len(prefix) == actions or prefix.count("P") == stages:
        yield prefix
        return
    for choice in "PMC":
        yield from sequences(stages, actions, prefix + choice)


def wrong(task, stage):
    result = deepcopy(task["evaluator"]["stage_references"][stage])
    if task["family"] == "constraint_grid":
        result["values"][0] = result["values"][1]
    elif task["family"] == "revision_ledger":
        result["values"][0] += 1
    else:
        width = task["contract"]["width"]
        for delta in range(1, 2**width):
            result["values"][1] = (task["evaluator"]["stage_references"][stage]["values"][1] + delta) % (2**width)
            if public_check(task, stage, result)["status"] == "public_mismatch":
                break
    assert public_check(task, stage, result)["status"] == "public_mismatch"
    return result


def writer(profile, state):
    value = {"established": [], "retained_observations": [], "uncertainties": []}
    if profile == "concise":
        value["established"] = [wire(state["feedback"])]
        value["uncertainties"] = ["A rejected candidate does not disprove the whole method."]
    else:
        value["established"] = [""]
        character = "x" if profile == "maximum_plain" else "\\"
        while True:
            value["established"][0] += character
            if len(wire(value).encode("utf-8")) > WRITER_BYTES:
                value["established"][0] = value["established"][0][:-1]
                break
    result = wire(value)
    parse_writer(result, "lesson")
    return result


def main():
    bundle = ROOT / "experiments/dependency_memory/results/rollback_challenge_v6_2026-10-09/prepared_screen"
    manifest, tasks = check_bundle(bundle)
    rows = []
    for profile in ("concise", "maximum_plain", "maximum_escaped"):
        note = {"concise": "Submitted the complete candidate for the currently released requirements.",
                "maximum_plain": "x" * 2048, "maximum_escaped": "\\" * 2048}[profile]
        # Stress writers contain syntactic padding; they do not simulate model semantics.
        fixed_writer = None if profile == "concise" else writer(profile, {})
        for task in tasks:
            bad = [wrong(task, i) for i in range(len(task["stages"]))]
            paths = list(sequences(len(task["stages"]), task["action_allowance"]))
            for arm in ("K", "R", "F"):
                row = {"profile": profile, "task_id": task["task_id"], "family": task["family"],
                       "level": task["difficulty"], "arm": arm, "scripted_paths": len(paths),
                       "capacity_paths": 0, "maximum_attempted_body_bound": 0, "largest_request": None}
                for path in paths:
                    def measured_render(t, state, kind, policy):
                        request = render(t, state, kind, policy)
                        if request.input_units > row["maximum_attempted_body_bound"]:
                            row["maximum_attempted_body_bound"] = request.input_units
                            row["largest_request"] = {"path": path, "next_kind": kind,
                                                      "used": state["used"], "stage": state["stage"] + 1}
                        return request

                    def invoke(identity, request):
                        state = json.loads(json.loads(request.json_text)["messages"][1]["content"])
                        if identity.stage == "lesson":
                            text = fixed_writer or writer(profile, state)
                        else:
                            choice = path[identity.step - 1]
                            stage = state["packet"]["stage"] - 1
                            value = candidate([]) if choice == "C" else (
                                task["evaluator"]["stage_references"][stage] if choice == "P" else bad[stage])
                            text = wire({"status": "continue" if choice == "C" else "candidate",
                                         "candidate": value, "note": note})
                        return SimpleNamespace(text=text, capped=False)

                    with patch.object(engine, "render", measured_render):
                        outcome = engine.run_episode(task, arm, invoke)
                    assert outcome["disposition"] in {"correct", "action_budget_exhausted", "context_capacity"}, outcome
                    row["capacity_paths"] += outcome["disposition"] == "context_capacity"
                rows.append(row)
        relevant = [r for r in rows if r["profile"] == profile]
        print(json.dumps({"profile": profile, "rows": len(relevant),
                          "maximum_attempted_body_bound": max(r["maximum_attempted_body_bound"] for r in relevant),
                          "capacity_rows": [{k: r[k] for k in ("family", "level", "arm", "capacity_paths", "largest_request")} for r in relevant if r["capacity_paths"]]}), flush=True)
    result = {"evidence_kind": "offline_scripted_capacity_probe", "model_generations": 0,
              "bundle": bundle.relative_to(ROOT).as_posix(), "manifest_sha256": read(bundle / "bundle.json")["manifest_sha256"],
              "method": "Run the actual engine for all P/M/C scripted paths, stopping at all stages passed or action cap. P uses an evaluator witness, M a same-shape candidate mutation verified to fail, C an empty continue action. All writers pass the actual parser. No provider calls.",
              "limitations": ["These are fixtures, not model observations or a probability distribution.",
                              "Stress padding tests schema-valid sizes, not semantic writer compliance.",
                              "Candidate lengths and integer widths stay near the witnesses; this is not a bound over all accepted outputs.",
                              "Paths can share prefixes and become identical when admission fails; counts are not independent trials.",
                              "The maximum is the largest attempted admission bound before the actual engine stops."],
              "rows": rows}
    (ROOT / "tmp/v6_capacity_probe.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
