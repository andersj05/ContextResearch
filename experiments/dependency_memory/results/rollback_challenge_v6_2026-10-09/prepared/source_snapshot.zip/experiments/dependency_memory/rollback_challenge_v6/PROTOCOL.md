# Rollback challenge v6: calibration before confirmation

October 9, 2026. New, repository-authored development tasks. No live v6 model
outcomes have been observed at preparation. The completed v5 allocation and all
its sources, receipts, ceilings and unknowns remain unchanged.

The purpose is to find a task distribution with room for both failure and
recovery, then measure rollback on independent tasks. Statistical significance
is a possible outcome, never a selection criterion or stopping rule.

## Questions and construction

Three finite families each have three levels. Levels are generator settings,
not claims about model difficulty:

| Family | Levels | What makes the question harder |
|---|---|---|
| Constraint grid | 4x4, 6x6, 9x9 | Coupled row/column/box, given-cell, cage-sum and inequality constraints; a locally valid change can violate another constraint |
| Bitvector program | 4/5/6-bit words, at most 3/5/7 operations | Infer a composition of add, XOR, multiply and rotate from examples; the final packet completes the full finite input domain |
| Revision ledger | 18/40/80 transaction IDs over 5/8/12 accounts | Revisions arrive out of order, replace entire transfers, and can void earlier work; later balances depend on earlier packets |

All accepted answers are finite integer arrays. Program candidates are a bounded
DSL, never submitted Python, eval, files or commands. A program is correct if
it matches the released examples, regardless of whether it matches the planted
program. Any valid grid is accepted; uniqueness is neither required nor claimed.
Ledger answers reconcile every transaction released so far, not future records.

Each seeded instance has a private witness and a checked answer at every stage.
Public graders are compared with separately formulated checks on witnesses,
mutations, hand fixtures and exhaustive small-word operation cases. This is
finite implementation verification, not a proof of model difficulty. There are
no hidden behavioral requirements or human judgments of correctness.

Records are partitioned across meaningful disclosure stages. Stage count and
action cap are frozen in the bundle and identical in calibration and confirmation.
Default: four stages, eight candidate actions. A smaller three-stage/five-action
screen is supported as a separately frozen design; it does not validate the
four-stage design. Stage depth, actual actions and visible history bytes are
reported. No actor is instructed to produce a wrong attempt. The deliberately
wrong first candidate used by offline fixtures is never a live task instruction.

## Access and interventions

The proposed operational target is GPT-6 Luna, medium effort, on the existing
subscription, preserving the v5 audited client route. Confirm the user's model
and allocation before dispatch. No API key, purchase or model fallback is used.
The model alias is mutable; immutable revision, provider sampling seed and actual
account charges are unavailable. Official interface references were read October
9: [Luna model](https://developers.openai.com/api/docs/models/gpt-6-luna) and
[app-server](https://learn.chatgpt.com/docs/app-server). The installed-client
preflight, not these pages, verifies the operational serialization contract.

Every action and writer starts a fresh process/thread in an empty workspace.
Only the public contract, current packet, accepted artifact, visible history,
retained memory, last feedback and remaining action count are allowed. Actors
cannot access witnesses, source seeds, future packets, evaluator files, task
archives, old provider threads, tools, network, or opaque reasoning replay.
The controller may read evaluator material; it is not part of the actor input.
Global client instructions and the visible tool registry are audited and pinned.

| Arm | At each eligible public mismatch |
|---|---|
| K | Append a model-written lesson; retain raw history |
| R | Append a model-written lesson; clear the entire current history field |
| Z | Clear raw history without a new lesson |
| G | Replace history and prior memory with a generic model-written summary |
| F | Fresh solve from initial artifact and all released packets, without trial feedback or lessons |

The last accepted artifact survives K/R/Z/G; rejected candidates are never
committed to it. A lesson may retain failed-candidate details. This intervention
changes visible representation; it does not erase all knowledge of a failure.
Independent K/R episodes have independent writers; this estimates full-policy
effect, not a matched-common-failure mechanism effect. Scheduled memory cuts and
native compaction are not tested in v6.

Writers use the same 4,096-byte structured contract as v5. All writers count in
usage. Every answer consumes an action, and no writer runs after the final action.
A malformed received answer is an observed failure. All serialized requests
must fit the 131,072-byte inherited admission bound. Bytes are not tokens.
This is an equal-action comparison, not equal token cost or verified equal dollars.

## Prospective stages and selection rule

1. **Screen:** K and F only, all nine family/level cells, normally two seeded
   replicates per cell. Within each family nominate the tier closest to K=57.5%,
   provided both arms are complete with at least two known tasks, K is in
   [25%,85%], F in [25%,90%], and K has a public mismatch on at least one episode.
   Ties choose the smaller level. Report every cell and all floors/ceilings.
   If none qualifies, nominate none. Screening is small-sample development.
2. **Validate difficulty:** new root seed and new identities, the exact nominated
   cells, same stages/actions/access contract, K and F only. Each cell requires
   at least eight complete tasks per arm, each arm's success in [40%,75%], and
   public mismatches on at least 25% of K episodes. The whole nominated mixture
   must pass. Do not silently remove a failed validation cell. These point-rate
   gates have sampling uncertainty; Wilson intervals are also reported.
3. **Confirm:** new seed/identities, same validated cells and access/action
   settings. Freeze a primary effect size, discordance assumption and fixed sample
   before any R/K outcomes. K/R are required; Z/G/F can be included as descriptive
   controls. Equal replicate counts per selected cell define the fixed mixture.

All selection artifacts bind audited live controls, their manifests and reports.
Offline fixtures cannot select difficulty or produce a confirmatory result.
Validation/confirmation preparation replays the source evidence before accepting
a selection. New seeds are necessary but do not establish new-family generality.

If the design stays saturated or falls to a floor, preserve the outcome and freeze
a new version/design. Do not change a live bundle, revisit inspected task IDs,
extend its sample until a p-value crosses a threshold, or tune on R-minus-K.

## Analysis and power

The sole confirmatory contrast is complete-episode binary success R minus K.
Report R-only, K-only, both-pass and both-fail pairs, effect size, fixed-denominator
missingness bounds, and the exact two-sided McNemar/binomial p-value at alpha .05.
Any missing selected outcome disables the confirmatory p-value; the complete-case
test remains descriptive. A significant negative effect is not a rollback gain.
Zero discordance is not equivalence. Secondary arms, family splits, resource use,
failed checks and history diagnostics are descriptive, without confirmatory claims.

Power is computed by summing over M~Bin(n,q) discordant pairs, then over
W|M~Bin(M,(q+delta)/(2q)), applying the exact two-sided test's rejection region.
For delta=.10 and q=.30, the 20-pair planning grid first reaches 80% at 260 pairs
(power approximately .81884). This is an assumed alternative, not measured power
or a guarantee of significance. A 260-pair two-arm design with eight actions has
at most 7,800 generations; it needs its own bounded allocation. With three equal
cells, round up to 261 tasks. Do not count generations, arms or packets as
independent task pairs. Provider time effects and fixed family membership limit
generalization; randomized nearby arm scheduling reduces but cannot erase them.

Resources are counted for all received calls including writers, and separately
on complete paired tasks. Input includes cached input; output includes reasoning,
both subsets counted once. The inherited planning-credit conversion is retained
as a declared accounting unit, not presented as current API pricing or actual
subscription debit. Unknown calls retain their reservations.

## Execution and boundedness

Four workers maximum. Freeze every call identity, seed, task, source hash, model,
effort, schedule and state-machine maximum in an immutable preparation bundle.
For action allowance H: K/R/G cost at most 2H-1 generations, Z/F at most H.
The max-calls option rejects a design whose full worst-case allocation exceeds
the budget; it does not truncate inconvenient late tasks. The standard screen
has 18 tasks, 36 episodes and a 414-generation maximum. The three-stage/five-action
screen has a 252-generation maximum. Neither count is a measured usage figure.

A central durable SQLite ledger admits each identity once, meters all replies,
enforces concurrency and the total ceiling, and rejects repeated provider threads.
Unknown dispatches end only that trajectory; unrelated work continues. Account,
source/client, information-access, ledger and evidence-write failures stop all
admissions. No automatic retries. Each completed run is sealed and independently
replayed/regraded without model calls. A global-stop continuation must use a new
output directory and verified receipt replay, preserving earlier unknowns and
counting previous admissions in the same allocation. Completed allocations cannot
be extended. A controller killed before sealing needs evidence recovery and is
not permission to relaunch; the exclusive launch marker remains authoritative
for duplicate prevention, not evidence that a process is still running.

Preparation, preview, tests, simulation, power calculation and audit make zero
provider generations. Only the explicit `launch --live` command dispatches.
