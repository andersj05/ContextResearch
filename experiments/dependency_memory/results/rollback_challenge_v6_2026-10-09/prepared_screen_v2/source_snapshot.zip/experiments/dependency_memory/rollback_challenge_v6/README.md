# Rollback challenge v6

Three new authored task families, exact graders, independent checks, a parallel
subscription runner, immutable freezes, receipt replay, control-only calibration
and a fixed-size paired test. **Difficulty is unmeasured until live calibration.**
The existing v5 experiment is not modified or reopened. See the [protocol](PROTOCOL.md).

## Task examples

- **Constraint grid:** complete a 4x4, 6x6 or 9x9 grid subject to row/column/box
  uniqueness, irregular cage sums, inequalities and gradually released givens.
- **Bitvector program:** find at most 3, 5 or 7 add/XOR/multiply/rotate operations
  matching a growing table of input/output examples. Any matching program passes.
- **Revision ledger:** reconcile balances across 18, 40 or 80 transaction IDs
  with out-of-order replacements and voids. Later packets revise earlier data.

All candidates are integer arrays. The program DSL runs in a finite interpreter;
there is no execution of arbitrary model-supplied Python. Private witnesses and
future packets stay out of actor requests. The ledger and grid families provide
different sources of history dependence; difficulty does not rely on padding.

## Offline preparation and verification

Run from the repository root with the existing Python installation. No new Python
packages, API key or Docker setup are needed for these finite task families.
Live dispatch uses the existing audited Luna-medium subscription client.

```powershell
python -m unittest experiments.dependency_memory.rollback_challenge_v6.test_challenge -v
python -m experiments.dependency_memory.rollback_challenge_v6.run prepare --output tmp/v6-screen --max-calls 414
python -m experiments.dependency_memory.rollback_challenge_v6.run preview --bundle tmp/v6-screen --task-index 0
python -m experiments.dependency_memory.rollback_challenge_v6.run simulate --bundle tmp/v6-screen --output tmp/v6-fixture --workers 4
python -m experiments.dependency_memory.rollback_challenge_v6.run audit --bundle tmp/v6-screen --run tmp/v6-fixture
python -m experiments.dependency_memory.rollback_challenge_v6.run power --effect .10 --discordance .30 --output tmp/v6-power.json
```

Use fresh paths for every preparation/run. A source change invalidates an existing
freeze. Simulation explicitly uses oracle fixtures; it cannot establish difficulty,
select live cells or produce a confirmatory p-value.

A smaller initial screen fits a 300-generation allocation:

```powershell
python -m experiments.dependency_memory.rollback_challenge_v6.run prepare --output tmp/v6-small-screen --stages 3 --actions 5 --max-calls 300
```

This has 18 tasks and at most 252 generations, including all K lessons. The later
validation must use the same three-stage/five-action settings. Validation and
confirmation need separate allocations; a screen alone does not satisfy them.

## Live screen, separate difficulty validation, then confirmation

After the model and bounded subscription allocation are settled, the runner
refreshes client/account checks and audits actual prompts against a loopback
endpoint before its first generation. No purchase or provider/model fallback.

```powershell
python -m experiments.dependency_memory.rollback_challenge_v6.run launch --bundle tmp/v6-screen --output tmp/v6-screen-live --workers 4 --live
python -m experiments.dependency_memory.rollback_challenge_v6.run audit --bundle tmp/v6-screen --run tmp/v6-screen-live
python -m experiments.dependency_memory.rollback_challenge_v6.run select --bundle tmp/v6-screen --run tmp/v6-screen-live --output tmp/v6-selected.json
python -m experiments.dependency_memory.rollback_challenge_v6.run prepare --split validation --seed 2026100929 --replicates 8 --selection tmp/v6-selected.json --output tmp/v6-validation
```

If no cell qualifies, the selection is empty and validation cannot launch. If
some qualify, launch and audit the separately budgeted validation bundle, then:

```powershell
python -m experiments.dependency_memory.rollback_challenge_v6.run validate --bundle tmp/v6-validation --run tmp/v6-validation-live --selection tmp/v6-selected.json --output tmp/v6-validated.json
```

Context-capacity failures stay in reported outcomes and denominators. A cell
with such a failure in K or F cannot be nominated, and a capacity failure during
validation prevents the entire nominated mixture from advancing. This avoids
mistaking a request-admission limit for model difficulty.

Confirmation preparation requires `--selection tmp/v6-validated.json`,
`--power-plan tmp/v6-power.json`, a new `--seed`, `--split confirmation`, and
enough `--replicates` per selected cell to cover the planned pair count. For
example, three selected cells and a 260-pair plan require 87 replicates per cell
(261 tasks). `--arms K R` is the minimum primary comparison. Add Z/G/F before
freezing if descriptive controls are needed. The CLI prints the full maximum
generation allocation before any live call; `--max-calls` enforces a chosen cap.

The fixed primary test can detect an effect in either direction. It does not
promise a benefit or statistical significance. Complete-case tests with missing
outcomes and all calibration analyses remain descriptive.

## Evidence and recovery

Each bundle saves task and source snapshots plus independent grader verification.
Each run saves requests, responses, job outcomes, analysis, SQLite metering and
a sealed inventory. All failed/unknown tasks retain their fixed denominators.
Inspect `analysis.json` for control success intervals, failure eligibility,
realized history bytes, paired outcomes and complete-pair resource totals.

A sealed global-stop run may be continued with `--prior <old-run>` and a fresh
output path. Known calls are replayed locally; unknown identities are never
resent. A completed allocation cannot be extended. Unsealed/crashed execution
must first be reconciled; never delete its launch marker to rerun it.

After code evolves, `audit --snapshot --bundle <bundle> --run <run>` verifies
the archive and replays using its historical source in a temporary directory.
Live dispatch and difficulty selection still require the current source to match
the frozen bundle. Historical replay cannot authorize a changed live allocation.
