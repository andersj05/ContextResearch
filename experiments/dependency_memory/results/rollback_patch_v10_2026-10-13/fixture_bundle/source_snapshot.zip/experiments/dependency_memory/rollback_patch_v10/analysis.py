"""Reuse frozen factorial analysis; the new cohort supplies its own seed."""
from ..rollback_patch_v9.analysis import analyze
